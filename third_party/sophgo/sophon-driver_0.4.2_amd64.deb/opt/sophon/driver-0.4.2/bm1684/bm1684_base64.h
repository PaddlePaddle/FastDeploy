int base64_prepare(struct bm_device_info *base64_bmdi, struct ce_base base);
int base64_start(struct bm_device_info *base64_bmdi);
