#ifndef __BM1684_FLASH_H_
#define __BM1684_FLASH_H_
#ifndef SOC_MODE
struct bm_device_info;
int bm1684_get_bootload_version(struct bm_device_info *bmdi);
#endif
#endif

