#ifndef _BM1682_GMEM_H_
#define _BM1682_GMEM_H_
int bmdrv_bm1682_parse_reserved_mem_info(struct bm_device_info *bmdi);
#endif
